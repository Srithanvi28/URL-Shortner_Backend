package com.spring.mongo.repository;

import com.spring.mongo.entity.ShortenedUrl;
import org.springframework.data.mongodb.repository.MongoRepository;

//This is the ShortenedUrlRepository which extends the MongoRepository
public interface ShortenedUrlRepository extends MongoRepository<ShortenedUrl, String> {
    ShortenedUrl findByShortCode(String shortCode);
}
